
#include "dynamic_pattern_database.h"

#include "scip/scip.h"
#include "scip/def.h"
#include "scip/scipdefplugins.h"

namespace heuristics {

    class DynamicPatternDatabaseScip : public DynamicPatternDatabase {
        public:
        
        DynamicPatternDatabaseScip(int variableCount, int maxSize, bool optimal) {
            this->variableCount = variableCount;
            this->maxSize = maxSize;
            this->optimal = optimal;
        }
    
    
        protected:
/**
 * Find the optimal h-value for this node by constructing an integer program to
 * solve the maximum weighted matching problem.
 * 
 * This implementation is quite dirty.  It creates the file in CPLEX format,
 * invokes SCIP via the std::system command (so it assumes scip is in the path),
 * redirects the output of SCIP to a file, and parses the file to get the bound.
 */
virtual float hOptimal(const varset& removedVariables) {
    
    /* create the scip instance */
    SCIP* scip;

    SCIP_CALL( SCIPcreate(&scip) );
    SCIP_CALL( SCIPincludeDefaultPlugins(scip) );

    #ifdef DEBUG
    SCIPinfoMessage(scip, NULL, "\n");
    SCIPinfoMessage(scip, NULL, "****************************************************\n");
    SCIPinfoMessage(scip, NULL, "* Running Exact Dynamic Pattern Database with SCIP *\n");
    SCIPinfoMessage(scip, NULL, "****************************************************\n");
    SCIPinfoMessage(scip, NULL, "\n");
    #endif
    

    // find the remaining variables
    VARSET_NEW(empty, variableCount);
    
    #ifdef DEBUG
    printf("finding valid patterns\n");
    #endif
    
    // now the weights, only include patterns that do not cover removed variables
    std::vector<varset> validPatterns;
    std::vector<float> patternScores;
    for (auto it = patterns.begin(); it != patterns.end(); it++) {
        varset pattern = (*it).first;
        if (VARSET_EQUAL(VARSET_AND(pattern, removedVariables), empty)) {
            validPatterns.push_back(pattern);
            patternScores.push_back( (*it).second );
        }
    }
    
    #ifdef DEBUG
    printf("creating empty problem\n");
    #endif
    /* create empty problem */
    SCIP_CALL( SCIPcreateProbBasic(scip, "dpd_exact") );
    
    #ifdef DEBUG
    printf("creating variables\n");
    #endif

    /* create varaibles */
    SCIP_VAR* x[validPatterns.size()];
    SCIP_VAR* a[variableCount][validPatterns.size()];
    
    char name[SCIP_MAXSTRLEN];

    for (int j = 0; j < validPatterns.size(); j++) {
        (void) SCIPsnprintf(name, SCIP_MAXSTRLEN, "x_%d", j);
        //SCIP_REAL lb = 0.0;
        //SCIP_REAL ub = 1.0;
        //SCIP_REAL obj = patternScores[j]; // this objective probably needs to be the cost of this pattern
        SCIP_CALL( SCIPcreateVarBasic(scip, &x[j], name, 0.0, 1.0, patternScores[j], SCIP_VARTYPE_BINARY) );
        
        for (int i = 0; i < variableCount; i++) {
            (void) SCIPsnprintf(name, SCIP_MAXSTRLEN, "a_%d_%d", i, j);
            //SCIP_REAL lb = 0.0;
            //SCIP_REAL ub = 1.0;
            //SCIP_REAL obj = 0.0;
            SCIP_CALL( SCIPcreateVarBasic(scip, &a[i][j], name, 0.0, 1.0, 0.0, SCIP_VARTYPE_BINARY) );
        }
    }
    
    #ifdef DEBUG
    printf("adding variables\n");
    #endif

    /* add variables to problem */
    for (int j = 0; j < validPatterns.size(); j++) {
        SCIP_CALL( SCIPaddVar(scip, x[j]) );
        
        for (int i = 0; i < variableCount; i++) {
            SCIP_CALL( SCIPaddVar(scip, a[i][j]) );
        }
    }

    /* now the constraints */
    
    // pick each remaining variable exactly once
    #ifdef DEBUG
    printf("creating pickOnce constraints\n");
    #endif
    for (int i = 0; i < variableCount; i++) {
        // skip removed variables
        if (VARSET_GET(removedVariables, i)) continue;
        
        (void) SCIPsnprintf(name, SCIP_MAXSTRLEN, "pickOnce_%d", i);
        
        SCIP_CONS *pickOnce;
        
        //SCIP_REAL lhs = 1.0;
        //SCIP_REAL rhs = 1.0;
        SCIP_CALL( SCIPcreateConsBasicLinear(scip, &pickOnce, name, 0, 0, NULL, 1.0, 1.0) );
        
        for (int j = 0; j < validPatterns.size(); j++) {
            SCIP_CALL( SCIPaddCoefLinear(scip, pickOnce, a[i][j], 1.0) );
        }
        
        #ifdef DEBUG
        printf("adding constraint\n");
        #endif
        SCIP_CALL( SCIPaddCons(scip, pickOnce) );
        
        #ifdef DEBUG
        printf("releasing constraint\n");
        #endif DEBUG
        SCIP_CALL( SCIPreleaseCons(scip, &pickOnce) );
    }
    
    // and we have to pick the variables in each valid pattern
#ifdef DEBUG    
    printf("creating pickPatternVar constraints\n");
#endif
    
    for (int j = 0; j < validPatterns.size(); j++) {
        varset pattern = validPatterns[j];
        
        // check which variables are in the pattern
        for (int i = 0; i < variableCount; i++) {
            if (VARSET_GET(pattern, i)) {
            
                (void) SCIPsnprintf(name, SCIP_MAXSTRLEN, "pickPatternVar,x_%d,a_%d_%d", j, i, j);
        
                SCIP_CONS *pickPatternVar;
                
                //SCIP_REAL lhs = 0.0;
                //SCIP_REAL rhs = 0.0;
                SCIP_CALL( SCIPcreateConsBasicLinear(scip, &pickPatternVar, name, 0, NULL, NULL, 0.0, 0.0) );
                
                SCIP_CALL( SCIPaddCoefLinear(scip, pickPatternVar, x[j], -1.0) );
                SCIP_CALL( SCIPaddCoefLinear(scip, pickPatternVar, a[i][j], 1.0) );
                
                SCIP_CALL( SCIPaddCons(scip, pickPatternVar) );
                SCIP_CALL( SCIPreleaseCons(scip, &pickPatternVar) );
            } else {
                // then the variable is not in this pattern
                // so a_ij is always 0
                (void) SCIPsnprintf(name, SCIP_MAXSTRLEN, "doNotPickPatternVar,x_%d,a_%d_%d", j, i, j);
        
                
                SCIP_CONS *doNotPickPatternVar;
                
                //SCIP_REAL lhs = 0.0;
                //SCIP_REAL rhs = 0.0;
                SCIP_CALL( SCIPcreateConsBasicLinear(scip, &doNotPickPatternVar, name, 0, NULL, NULL, 0.0, 0.0) );
                
                SCIP_CALL( SCIPaddCoefLinear(scip, doNotPickPatternVar, a[i][j], 1.0) );
                
                SCIP_CALL( SCIPaddCons(scip, doNotPickPatternVar) );
                SCIP_CALL( SCIPreleaseCons(scip, &doNotPickPatternVar) );
            }
        }
    }
    
    /* release variables since we no longer need them */
    for (int j = 0; j < validPatterns.size(); j++) {
        SCIP_CALL( SCIPreleaseVar(scip, &x[j]) );
        
        for (int i = 0; i < variableCount; i++) {
            SCIP_CALL( SCIPreleaseVar(scip, &a[i][j]) );
        }
    }
   
    // Set maximization
    SCIP_CALL_ABORT( SCIPsetObjsense(scip, SCIP_OBJSENSE_MAXIMIZE) );  
    
    SCIP_CALL( SCIPsetMessagehdlr(scip, NULL) );
    
    //SCIPinfoMessage(scip, NULL, "Original problem:\n");
    //SCIP_CALL( SCIPprintOrigProblem(scip, NULL, "cip", FALSE) );  
    
    //SCIPinfoMessage(scip, NULL, "\nPresolving...\n");
    SCIP_CALL( SCIPpresolve(scip) );

    //SCIPinfoMessage(scip, NULL, "\nSolving...\n");
    SCIP_CALL( SCIPsolve(scip) );

    SCIP_CALL( SCIPfreeTransform(scip) );
    

    int nsols = SCIPgetNSols(scip);
    SCIP_SOL **sols = SCIPgetSols(scip);
    
    float h = SCIPgetSolOrigObj(scip, sols[0]);
    
    for (int i = 1; i < nsols; i++) {
        float newH = SCIPgetSolOrigObj(scip, sols[i]);
        if (newH > h) {
            h = newH;
        }    
    }
    //printf("h: %f\n", h);

    SCIP_CALL( SCIPfree(&scip) );
    
    return h;
}
        
    
    };
}
