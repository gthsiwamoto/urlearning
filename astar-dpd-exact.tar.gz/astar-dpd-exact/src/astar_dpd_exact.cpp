/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/*                                                                           */
/*                  This file is part of the program and library             */
/*         SCIP --- Solving Constraint Integer Programs                      */
/*                                                                           */
/*    Copyright (C) 2002-2013 Konrad-Zuse-Zentrum                            */
/*                            fuer Informationstechnik Berlin                */
/*                                                                           */
/*  SCIP is distributed under the terms of the ZIB Academic License.         */
/*                                                                           */
/*  You should have received a copy of the ZIB Academic License              */
/*  along with SCIP; see the file COPYING. If not email to scip@zib.de.      */
/*                                                                           */
/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

/**@file   string.c
 * @brief  Coil Compression String Design model
 * @author Stefan Vigerske
 *
 * This example shows how to setup quadratic and nonlinear constraints in SCIP when using SCIP as callable library.
 * The example implements a model for the design of a coil compression string as it can be found in the GAMS model library:
 * http://www.gams.com/modlib/libhtml/spring.htm
 *
 * The task is to find a minimum volume of a wire for the production of a coil compression spring.
 *
 * Original model source:
 * @par
 *    E. Sangren@n
 *    Nonlinear Integer and Discrete Programming in Mechanical Design Optimization@n
 *    Journal of Mechanical Design, Trans. ASME 112 (1990), 223-229
 */

/*--+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8----+----9----+----0----+----1----+----2*/

#include <stdio.h>
#include <math.h>

#include "typedefs.h"
#include "bayesian_network.h"
#include "dynamic_pattern_database_scip.h"

#include "scip/scip.h"
#include "scip/scipdefplugins.h"

/* 
 * File:   main.cpp
 * Author: malone
 *
 * Created on August 6, 2012, 9:05 PM
 */

#include <string>
#include <iostream>
#include <ostream>
#include <vector>
#include <cstdlib>

#include <boost/program_options.hpp>
#include <boost/timer/timer.hpp>
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include "typedefs.h"
#include "score_cache.h"
#include "priority_queue.h"
#include "node.h"
#include "hugin_structure_writer.h"

#include "best_score_calculator.h"
#include "best_score_creator.h"

#include "heuristic.h"
#include "heuristic_creator.h"

namespace po = boost::program_options;


/**
 * A timer to keep track of how long the algorithm has been running.
 */
boost::asio::io_service io;

/**
 * A variable to check if the user-specified time limit has expired.
 */
bool outOfTime;

/**
 * The path to the score cache file.
 */
std::string scoreFile;

/**
 * The data structure to use to calculate best parent set scores.
 * "tree", "list", "bitwise"
 */
std::string bestScoreCalculator;

/**
 * The type of heuristic to use.
 */
std::string heuristicType;

/**
 * The argument for creating the pattern database.
 */
int heuristicArgument;

/**
 * The file to write the learned network.
 */
std::string netFile;

/**
 * The number of nodes expanded during the search.
 */
int nodesExpanded;

/**
 * The maximum running time for the algorithm.
 */
int runningTime;

/**
 * Handler when out of time.
 */
void timeout(const boost::system::error_code& /*e*/) {
    printf("Out of time\n");
    outOfTime = true;
}

std::vector<varset> reconstructSolution(Node *goal, std::vector<bestscorecalculators::BestScoreCalculator*> &spgs, NodeMap &closedList) {
    std::vector<varset> optimalParents;
    for (int i = 0; i < spgs.size(); i++) {
        optimalParents.push_back(VARSET(spgs.size()));
    }

    VARSET_COPY(goal->getSubnetwork(), remainingVariables);
    Node *current = goal;
    float score = 0;
    for (int i = 0; i < spgs.size(); i++) {
        int leaf = current->getLeaf();
        score += spgs[leaf]->getScore(remainingVariables);
        varset parents = spgs[leaf]->getParents();
        optimalParents[leaf] = parents;

        VARSET_CLEAR(remainingVariables, leaf);

        current = closedList[remainingVariables];
    }

    return optimalParents;
}

void astar() {
    printf("URLearning, A*\n");
    printf("Dataset: '%s'\n", scoreFile.c_str());
    printf("Net file: '%s'\n", netFile.c_str());
    printf("Best score calculator: '%s'\n", bestScoreCalculator.c_str());
    printf("Heuristic type: '%s'\n", heuristicType.c_str());
    printf("Heuristic argument: '%d'\n", heuristicArgument);

    boost::timer::auto_cpu_timer act;

    printf("Reading score cache.\n");
    scoring::ScoreCache cache;
    cache.read(scoreFile);
    int variableCount = cache.getVariableCount();

    act.start();
    printf("Creating BestScore calculators.\n");
    std::vector<bestscorecalculators::BestScoreCalculator*> spgs = bestscorecalculators::create(bestScoreCalculator, cache);
    act.stop();
    act.report();

    act.start();
    printf("Creating heuristic.\n");
    //heuristics::Heuristic *heuristic = heuristics::create(heuristicType, heuristicArgument, spgs);
    heuristics::Heuristic *heuristic = new heuristics::DynamicPatternDatabaseScip(spgs.size(), heuristicArgument, true);
    heuristic->initialize(spgs);
    
#ifdef DEBUG
    heuristic->print();
#endif
    
    act.stop();
    act.report();


    VARSET_NEW(empty, variableCount);
    float lb = heuristic->h(empty);

    NodeMap generatedNodes;
    init_map(generatedNodes);

    PriorityQueue openList;

    byte leaf(0);
    Node *root = new Node(0.0f, lb, empty, leaf);
    openList.push(root);

    Node *goal = NULL;
    VARSET_NEW(allVariables, variableCount);
    VARSET_SET_ALL(allVariables, variableCount);

    act.start();
    printf("Beginning search\n");
    nodesExpanded = 0;
    while (openList.size() > 0 && !outOfTime) {
        Node *u = openList.pop();
        nodesExpanded++;
        
        if (nodesExpanded % 100 == 0) {
            std::cout << ".";
            std::cout.flush();
        }

        varset variables = u->getSubnetwork();

        // check if it is the goal
        if (variables == allVariables) {
            goal = u;
            break;
        }

        // note that it is in the closed list
        u->setPqPos(-2);

        // expand
        for (byte leaf = 0; leaf < variableCount; leaf++) {
            // make sure this variable was not already present
            if (VARSET_GET(variables, leaf)) continue;

            // get the new variable set
            VARSET_COPY(variables, newVariables);
            VARSET_SET(newVariables, leaf);


            Node *succ = generatedNodes[newVariables];

            // check if this is the first time we have generated this node
            if (succ == NULL) {
                // get the cost along this path
                float g = u->getG() + spgs[leaf]->getScore(newVariables);
                // calculate the heuristic estimate
                float h = heuristic->h(newVariables);

                // update all the values
                succ = new Node(g, h, newVariables, leaf);

                // add it to the open list
                openList.push(succ);

                // and to the list of generated nodes
                generatedNodes[newVariables] = succ;
                continue;
            }

            // assume the heuristic is consistent
            // so check if it was in the closed list
            if (succ->getPqPos() == -2) {
                continue;
            }
            // so we have generated a node in the open list
            // see if the new path is better
            float g = u->getG() + spgs[leaf]->getScore(variables);
            if (g < succ->getG()) {
                // the update the information
                succ->setLeaf(leaf);
                succ->setG(g);

                // and the priority queue
                openList.update(succ);
            }
        }
    }
    act.stop();
    act.report();

    printf("Nodes expanded: %d\n", nodesExpanded);

    if (goal != NULL) {
        printf("Found solution: %f\n", goal->getF());

        if (netFile.length() > 0) {

            datastructures::BayesianNetwork *network = cache.getNetwork();
            network->fixCardinalities();
            std::vector<varset> optimalParents = reconstructSolution(goal, spgs, generatedNodes);
            network->setParents(optimalParents);
            network->setUniformProbabilities();

            fileio::HuginStructureWriter writer;
            writer.write(network, netFile);
        }
    } else {
        Node *u = openList.pop();
        printf("No solution found.\n");
        printf("Lower bound: %f\n", u->getF());
    }
}

int main(int argc, char** argv) {

    boost::timer::auto_cpu_timer act;

    std::string description = std::string("Learn an optimal Bayesian network using A*.  Example usage: ") + argv[0] + " iris.pss";
    po::options_description desc(description);

    desc.add_options()
            ("scoreFile", po::value<std::string > (&scoreFile)->required(), "The file containing the local scores in pss format. First positional argument.")
            ("bestScore,b", po::value<std::string > (&bestScoreCalculator)->default_value("list"), "The data structure to use for BestScore calculations. [\"list\", \"tree\", \"bitwise\"]")
            ("heuristic,e", po::value<std::string> (&heuristicType)->default_value("static"), "The type of heuristic to use. [\"static\", \"dynamic_optimal\", \"dynamic\"]")
            ("argument,a", po::value<int> (&heuristicArgument)->default_value(2), "The argument for creating the heuristic, such as number of pattern databases to use.")
            ("runningTime,r", po::value<int> (&runningTime)->default_value(0), "The maximum running time for the algorithm.  0 means no running time.")
            ("netFile,n", po::value<std::string > (&netFile)->default_value(""), "The file to which the learned network is written.  Leave blank to not create the file.")
            ("help,h", "Show this help message.")
            ;

    po::positional_options_description positionalOptions;
    positionalOptions.add("scoreFile", 1);

    po::variables_map vm;
    po::store(po::command_line_parser(argc, argv).options(desc)
            .positional(positionalOptions).run(),
            vm);

    if (vm.count("help") || argc == 1) {
        std::cout << desc;
        return 0;
    }

    po::notify(vm);
    outOfTime = false;

    boost::to_lower(bestScoreCalculator);

    boost::asio::deadline_timer t(io);
    if (runningTime > 0) {
        printf("Maximum running time: %d\n", runningTime);
        t.expires_from_now(boost::posix_time::seconds(runningTime));
        t.async_wait(timeout);
        boost::thread workerThread(astar);
        io.run();
        workerThread.join();
    } else {
        astar();
    }

    return 0;
}

